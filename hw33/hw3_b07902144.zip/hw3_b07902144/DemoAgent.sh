read -p "Please enter lossrate: " lossrate      # 提示使用者輸入
./agent local local 8887 8888 8889 ${lossrate}

